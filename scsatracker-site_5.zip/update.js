// Public "Update my information" form. It can only submit to the review queue through one
// database function (submit_self_update); it cannot read the member list.
(() => {
  const MILES = [
    ['membership', 'Discovering Membership Class'], ['baptism', 'Baptism'],
    ['lifeCenter', 'Joined a Life Center'], ['workers', "Workers' Training"],
    ['placement', 'Ministry Placement Assessment'], ['serving', 'Serving in a ministry'],
    ['lead', 'Leading or assisting a ministry or Life Center'],
  ];
  const $ = s => document.querySelector(s);
  const today = new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  $('#miles').innerHTML = MILES.map(([k, l]) => `<label>${l}<input type="date" data-mile="${k}" max="${today}"></label>`).join('');
  $('#joined').max = today;
  const cfg = window.SCSA_CONFIG || {};
  document.querySelectorAll('[data-site]').forEach(el => { const v = cfg[el.dataset.site]; if(v) el.textContent = v; });
  const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth: { persistSession: false } });
  const showErr = msg => { const e = $('#err'); e.textContent = msg; e.hidden = !msg; if (msg) e.scrollIntoView({ block: 'nearest' }); };

  $('#f').addEventListener('submit', async ev => {
    ev.preventDefault(); showErr('');
    const code = $('#code').value.trim(), name = $('#name').value.trim(), phone = $('#phone').value.trim();
    if (!code) return showErr('Enter the church code.');
    if (name.split(/\s+/).length < 2) return showErr('Please enter your first and last name.');
    if (phone.replace(/\D/g, '').length < 10) return showErr('Please enter your phone number, including area code.');
    const milestones = {};
    document.querySelectorAll('[data-mile]').forEach(i => { if (i.value) milestones[i.dataset.mile] = i.value; });
    const btn = $('#send'); btn.disabled = true; btn.textContent = 'Sending…';
    const { error } = await sb.rpc('submit_self_update', {
      p_code: code, p_name: name, p_phone: phone, p_joined: $('#joined').value || null,
      p_milestones: milestones, p_note: $('#note').value.trim(),
    });
    btn.disabled = false; btn.textContent = 'Send my update';
    if (error) { console.error(error); return showErr(error.message && error.message.length < 120 ? error.message : 'Something went wrong. Please try again.'); }
    $('#f').hidden = true; $('#done').hidden = false; window.scrollTo(0, 0);
  });
})();
